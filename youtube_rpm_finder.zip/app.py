
import streamlit as st

st.set_page_config(page_title="YouTube RPM Finder", page_icon="📈")

RPM_DATA = {
    "Finance": (8, 30),
    "Business": (6, 20),
    "Technology": (4, 15),
    "AI": (5, 18),
    "Education": (3, 12),
    "Gaming": (1, 5),
    "Entertainment": (0.5, 4),
    "Lifestyle": (1, 6),
    "Health": (2, 10),
    "Real Estate": (8, 25)
}

st.title("📈 YouTube RPM Finder")

niche = st.selectbox("Select a niche", list(RPM_DATA.keys()))
views = st.number_input("Monthly Views", min_value=0, value=100000)

rpm_min, rpm_max = RPM_DATA[niche]
avg_rpm = (rpm_min + rpm_max) / 2

estimated_revenue = (views / 1000) * avg_rpm

competition = {
    "Finance": "High",
    "Business": "Medium",
    "Technology": "High",
    "AI": "Medium",
    "Education": "Medium",
    "Gaming": "Very High",
    "Entertainment": "Very High",
    "Lifestyle": "High",
    "Health": "Medium",
    "Real Estate": "Low"
}

st.subheader("Results")
st.write(f"Estimated RPM Range: ${rpm_min} - ${rpm_max}")
st.write(f"Average RPM: ${avg_rpm:.2f}")
st.write(f"Estimated Monthly Revenue: ${estimated_revenue:,.2f}")
st.write(f"Competition Level: {competition[niche]}")
